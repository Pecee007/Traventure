TripAdvisor Annotated Dataset

The full TripAdvisor dataset consists of 235,793 hotel reviews crawled over a period of one month. In addition to the review text, each review comes with a hotel identifier, an overall rating and optional aspect-specific ratings for the following seven aspects: Rooms, Cleanliness, Value, Service, Location, Checkin, and Business. All review-level ratings are on a discrete ordinal scale from 1 to 5 (with -1 indicating that an aspect-specific rating was not provided by the reviewer).

- Annotation

The annotations are related to nine aspects typically mentioned in hotel reviews. In addition to the seven aspects explicitly present (at the review level) in the TripAdvisor dataset, we decided to add two other aspects (aspectFood and Building), since many comments in the reviews refer to them. Furthermore, the “catch-all” aspects Other and NotRelated were added, for a total of eleven aspects. Other captures those opinion-related aspects that cannot be assigned to any of the first nine aspects, but which are still about the hotel under review, for example, Extremely friendly place. The NotRelated aspect captures those opinion-related aspects that are not relevant to the hotel under review, as for example in The crew on our flight were wonderful. 

The annotation distinguishes between Positive, Negative and Neutral/Mixed opinions. The Neutral/Mixed label is assigned to opinions that are about an aspect without expressing a polarized opinion, and to opinions of contrasting polarities, such as The room was average size (neutral) and Pricey but worth it! (mixed). The annotations also distinguish between explicit and implicit opinion expressions, that is, between expressions that refer directly to an aspect and expressions that refer indirectly to an aspect by referring to some other property/entity that is related to the aspect. For example, Fine rooms is an explicitly expressed positive opinion concerning the Rooms aspect, while We had great views over the East River is an implicitly expressed positive opinion concerning the Location aspect, and All doors seem to have to slam to close is an implicit negative opinion concerning the Rooms aspect.


This archive conitains:
This README file,
The ./tripadvisor directory with the three file: test.zero.json, test.one.json adn test.two.json; these are the annotated reviews shared by the three annotators Zero, One and Two. The ./tripadvisor directory also contains the train.unique.json and test.unique.json, that are training and test files where each review is annotated by only one annotator.


